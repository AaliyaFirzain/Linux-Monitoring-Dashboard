"""
Memory Monitoring Module
Parses /proc/meminfo to extract genuine Linux physical RAM and swap statistics,
computing precise memory utilization percentages without any hardcoded values.
"""

import os
from typing import Dict, Any, Optional


def parse_meminfo(meminfo_path: str = "/proc/meminfo") -> Optional[Dict[str, int]]:
    """
    Reads /proc/meminfo and parses all memory statistics into a dictionary with integer values (in kB).
    Example lines:
      MemTotal:       16279188 kB
      MemFree:         4352112 kB
      MemAvailable:   11204856 kB
    """
    if not os.path.exists(meminfo_path):
        return None

    mem_data: Dict[str, int] = {}
    try:
        with open(meminfo_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                parts = line.strip().split(":")
                if len(parts) == 2:
                    key = parts[0].strip()
                    val_parts = parts[1].strip().split()
                    if val_parts:
                        try:
                            # Typically in kB
                            mem_data[key] = int(val_parts[0])
                        except ValueError:
                            pass
    except (OSError, IOError):
        return None

    return mem_data


def format_bytes(kb: int) -> Dict[str, Any]:
    """Converts a value in kilobytes to human-readable units (kB, MB, GB)."""
    mb = kb / 1024.0
    gb = kb / (1024.0 * 1024.0)
    return {
        "raw_kb": kb,
        "mb": round(mb, 2),
        "gb": round(gb, 2),
        "formatted": f"{round(gb, 2)} GB" if gb >= 1.0 else f"{round(mb, 1)} MB",
    }


def get_memory_info(meminfo_path: str = "/proc/meminfo") -> Dict[str, Any]:
    """
    Computes dynamic RAM and Swap usage directly from /proc/meminfo.

    Calculation Methodology:
    1. MemTotal: Total physical RAM available to Linux kernel.
    2. MemAvailable: Linux kernel estimate of memory available to launch new applications
       without swapping (available in kernel >= 3.14).
    3. Used RAM = MemTotal - MemAvailable
       (Fallback for older kernels: MemTotal - MemFree - Buffers - Cached)
    4. Memory Utilization % = (Used RAM / MemTotal) * 100
    """
    raw_data = parse_meminfo(meminfo_path)
    if raw_data is None or "MemTotal" not in raw_data:
        return {
            "supported": False,
            "error": f"{meminfo_path} not found or unreadable. Linux /proc filesystem required.",
        }

    mem_total_kb = raw_data.get("MemTotal", 0)
    mem_free_kb = raw_data.get("MemFree", 0)
    buffers_kb = raw_data.get("Buffers", 0)
    cached_kb = raw_data.get("Cached", 0)
    sreclaimable_kb = raw_data.get("SReclaimable", 0)
    swap_total_kb = raw_data.get("SwapTotal", 0)
    swap_free_kb = raw_data.get("SwapFree", 0)

    # Modern Linux kernel provides MemAvailable
    if "MemAvailable" in raw_data:
        mem_available_kb = raw_data["MemAvailable"]
        mem_used_kb = max(0, mem_total_kb - mem_available_kb)
        calculation_method = "MemTotal - MemAvailable (Modern Linux Kernel 3.14+ standard)"
    else:
        # Fallback for older Linux kernels
        mem_available_kb = mem_free_kb + buffers_kb + cached_kb + sreclaimable_kb
        mem_used_kb = max(0, mem_total_kb - (mem_free_kb + buffers_kb + cached_kb))
        calculation_method = "MemTotal - MemFree - Buffers - Cached (Legacy kernel fallback)"

    utilization_pct = (mem_used_kb / mem_total_kb * 100.0) if mem_total_kb > 0 else 0.0

    # Swap metrics
    swap_used_kb = max(0, swap_total_kb - swap_free_kb)
    swap_pct = (swap_used_kb / swap_total_kb * 100.0) if swap_total_kb > 0 else 0.0

    return {
        "supported": True,
        "calculation_method": calculation_method,
        "total_ram": format_bytes(mem_total_kb),
        "used_ram": format_bytes(mem_used_kb),
        "available_ram": format_bytes(mem_available_kb),
        "free_ram": format_bytes(mem_free_kb),
        "buffers": format_bytes(buffers_kb),
        "cached": format_bytes(cached_kb),
        "memory_utilization_percent": round(utilization_pct, 2),
        "swap": {
            "total": format_bytes(swap_total_kb),
            "used": format_bytes(swap_used_kb),
            "free": format_bytes(swap_free_kb),
            "utilization_percent": round(swap_pct, 2),
        },
    }
