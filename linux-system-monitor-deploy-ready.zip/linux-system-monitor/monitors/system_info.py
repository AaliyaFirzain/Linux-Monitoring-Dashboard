"""
System Information Monitor
Retrieves OS distribution, kernel version, hostname, and machine architecture
from Linux system interfaces: /etc/os-release, /proc/version, and standard OS interfaces.
"""

import os
import platform
from typing import Dict, Any


def parse_os_release(filepath: str = "/etc/os-release") -> Dict[str, str]:
    """
    Parses key-value pairs from /etc/os-release or /usr/lib/os-release.
    Standardized by systemd and supported across all modern Linux distributions.
    """
    data = {}
    alt_path = "/usr/lib/os-release"
    target_path = filepath if os.path.exists(filepath) else (alt_path if os.path.exists(alt_path) else None)
    
    if not target_path:
        return data

    try:
        with open(target_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    key, val = line.split("=", 1)
                    key = key.strip()
                    val = val.strip().strip('"').strip("'")
                    data[key] = val
    except (OSError, IOError) as e:
        data["read_error"] = str(e)

    return data


def get_proc_version() -> str:
    """Reads Linux kernel build and compiler information from /proc/version."""
    proc_version_path = "/proc/version"
    if os.path.exists(proc_version_path):
        try:
            with open(proc_version_path, "r", encoding="utf-8", errors="replace") as f:
                return f.read().strip()
        except (OSError, IOError):
            pass
    return ""


def get_system_info() -> Dict[str, Any]:
    """
    Dynamically retrieves genuine system information.
    Checks whether genuine Linux interfaces (/proc, /etc/os-release) are present.
    """
    is_linux = platform.system() == "Linux"
    has_proc = os.path.isdir("/proc")

    if not is_linux or not has_proc:
        return {
            "supported": False,
            "error": "Linux /proc virtual filesystem not detected. Genuine Linux environment required.",
            "current_os": platform.system(),
            "current_release": platform.release(),
            "hostname": platform.node(),
            "architecture": platform.machine(),
        }

    os_release = parse_os_release()
    distro_name = os_release.get("NAME", os_release.get("PRETTY_NAME", "Linux"))
    distro_version = os_release.get("VERSION", os_release.get("VERSION_ID", "Unknown"))
    distro_id = os_release.get("ID", "linux")
    pretty_name = os_release.get("PRETTY_NAME", f"{distro_name} {distro_version}".strip())

    # Kernel release and node name
    try:
        uname = os.uname()
        kernel_version = uname.release
        hostname = uname.nodename
        machine_arch = uname.machine
    except AttributeError:
        kernel_version = platform.release()
        hostname = platform.node()
        machine_arch = platform.machine()

    proc_version = get_proc_version()

    return {
        "supported": True,
        "os_name": platform.system(),
        "distribution_name": distro_name,
        "distribution_version": distro_version,
        "distribution_id": distro_id,
        "pretty_name": pretty_name,
        "kernel_version": kernel_version,
        "hostname": hostname,
        "machine_architecture": machine_arch,
        "proc_version_summary": proc_version,
    }
