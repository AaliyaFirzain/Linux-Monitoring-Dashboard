"""
System Load Average Monitor
Parses /proc/loadavg to extract standard Unix 1-minute, 5-minute, and 15-minute
exponentially damped moving load averages and process scheduling counters.
"""

import os
from typing import Dict, Any


def get_load_info(loadavg_path: str = "/proc/loadavg") -> Dict[str, Any]:
    """
    Reads /proc/loadavg.
    Line structure:
      <load1> <load5> <load15> <runnable>/<total_threads> <last_pid>
    Example:
      0.18 0.25 0.22 1/512 12948
    """
    if not os.path.exists(loadavg_path):
        return {
            "supported": False,
            "error": f"{loadavg_path} not found. Linux /proc filesystem required.",
        }

    try:
        with open(loadavg_path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read().strip()
            parts = content.split()
            if len(parts) < 3:
                return {
                    "supported": False,
                    "error": f"Unexpected format in {loadavg_path}",
                }

            load_1m = float(parts[0])
            load_5m = float(parts[1])
            load_15m = float(parts[2])

            runnable_entities = 0
            total_entities = 0
            if len(parts) >= 4 and "/" in parts[3]:
                thread_parts = parts[3].split("/")
                runnable_entities = int(thread_parts[0])
                total_entities = int(thread_parts[1])

            last_pid = int(parts[4]) if len(parts) >= 5 and parts[4].isdigit() else None

    except (OSError, IOError, ValueError) as e:
        return {
            "supported": False,
            "error": f"Failed reading {loadavg_path}: {str(e)}",
        }

    return {
        "supported": True,
        "load_1m": load_1m,
        "load_5m": load_5m,
        "load_15m": load_15m,
        "runnable_entities": runnable_entities,
        "total_scheduling_entities": total_entities,
        "last_created_pid": last_pid,
    }
