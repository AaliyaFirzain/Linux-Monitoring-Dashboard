"""
CPU Monitoring Module
Parses /proc/cpuinfo and /proc/stat to compute dynamic, mathematically accurate
CPU utilization percentages and processor metadata without any simulated or mock values.
"""

import os
import time
import threading
from typing import Dict, Any, List, Optional, Tuple


class CPUMonitor:
    """
    Tracks successive CPU time measurements from /proc/stat to compute genuine
    system and per-core CPU utilization percentages.
    """

    def __init__(self, stat_path: str = "/proc/stat", cpuinfo_path: str = "/proc/cpuinfo"):
        self.stat_path = stat_path
        self.cpuinfo_path = cpuinfo_path
        self._lock = threading.Lock()
        
        # Previous counters for overall CPU: (idle_all, total)
        self._prev_overall: Optional[Tuple[int, int]] = None
        # Previous counters for individual cores: core_id -> (idle_all, total)
        self._prev_cores: Dict[int, Tuple[int, int]] = {}
        self._last_sample_time: float = 0.0

    def parse_cpuinfo(self) -> Dict[str, Any]:
        """
        Parses /proc/cpuinfo to extract CPU model, architecture details,
        cache size, clock speed, and core counts.
        """
        if not os.path.exists(self.cpuinfo_path):
            return {
                "model_name": "Unknown",
                "vendor_id": "Unknown",
                "core_count": 0,
                "cpu_mhz": "Unknown",
                "cache_size": "Unknown",
                "flags_sample": [],
            }

        model_name = "Unknown"
        vendor_id = "Unknown"
        cpu_mhz = "Unknown"
        cache_size = "Unknown"
        flags: List[str] = []
        processor_count = 0

        try:
            with open(self.cpuinfo_path, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    if ":" in line:
                        key, val = [part.strip() for part in line.split(":", 1)]
                        key_lower = key.lower()
                        if key_lower == "processor":
                            processor_count += 1
                        elif key_lower == "model name" and model_name == "Unknown":
                            model_name = val
                        elif key_lower == "vendor_id" and vendor_id == "Unknown":
                            vendor_id = val
                        elif key_lower in ("cpu mhz", "clock") and cpu_mhz == "Unknown":
                            cpu_mhz = val
                        elif key_lower == "cache size" and cache_size == "Unknown":
                            cache_size = val
                        elif key_lower in ("flags", "features") and not flags:
                            flags = val.split()[:15]  # first 15 architectural flags
        except (OSError, IOError):
            pass

        return {
            "model_name": model_name,
            "vendor_id": vendor_id,
            "core_count": processor_count if processor_count > 0 else 1,
            "cpu_mhz": cpu_mhz,
            "cache_size": cache_size,
            "flags_sample": flags,
        }

    def _read_stat_lines(self) -> Tuple[Optional[List[int]], Dict[int, List[int]]]:
        """
        Reads /proc/stat and returns raw jiffies for aggregate CPU and per-core lines.
        Line format: cpu user nice system idle iowait irq softirq steal guest guest_nice
        """
        if not os.path.exists(self.stat_path):
            return None, {}

        overall_stats: Optional[List[int]] = None
        per_core_stats: Dict[int, List[int]] = {}

        try:
            with open(self.stat_path, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    parts = line.strip().split()
                    if not parts:
                        continue
                    label = parts[0]
                    if label == "cpu":
                        # Aggregate CPU line
                        overall_stats = [int(p) for p in parts[1:]]
                    elif label.startswith("cpu") and label[3:].isdigit():
                        # Core specific line (e.g., cpu0, cpu1)
                        core_id = int(label[3:])
                        per_core_stats[core_id] = [int(p) for p in parts[1:]]
        except (OSError, IOError, ValueError):
            pass

        return overall_stats, per_core_stats

    @staticmethod
    def _compute_usage_from_jiffies(prev: Tuple[int, int], curr_stats: List[int]) -> Tuple[float, Tuple[int, int]]:
        """
        Given previous (idle_all, total) and current jiffies list, calculates CPU utilization percentage.
        Jiffies: user, nice, system, idle, iowait, irq, softirq, steal, guest, guest_nice
        Formula:
          idle_all = idle + iowait
          non_idle = user + nice + system + irq + softirq + steal
          total = idle_all + non_idle
          utilization = ((delta_total - delta_idle) / delta_total) * 100
        """
        user = curr_stats[0] if len(curr_stats) > 0 else 0
        nice = curr_stats[1] if len(curr_stats) > 1 else 0
        system = curr_stats[2] if len(curr_stats) > 2 else 0
        idle = curr_stats[3] if len(curr_stats) > 3 else 0
        iowait = curr_stats[4] if len(curr_stats) > 4 else 0
        irq = curr_stats[5] if len(curr_stats) > 5 else 0
        softirq = curr_stats[6] if len(curr_stats) > 6 else 0
        steal = curr_stats[7] if len(curr_stats) > 7 else 0

        idle_all = idle + iowait
        non_idle = user + nice + system + irq + softirq + steal
        total = idle_all + non_idle

        prev_idle, prev_total = prev
        total_delta = total - prev_total
        idle_delta = idle_all - prev_idle

        if total_delta <= 0:
            usage = 0.0
        else:
            usage = ((total_delta - idle_delta) / total_delta) * 100.0
            usage = max(0.0, min(100.0, usage))

        return round(usage, 2), (idle_all, total)

    def get_cpu_utilization(self) -> Dict[str, Any]:
        """
        Computes dynamic CPU utilization.
        If this is the initial call, captures an immediate consecutive sample (0.1s delta)
        to guarantee a mathematically valid initial reading without hardcoding.
        """
        if not os.path.exists(self.stat_path):
            return {
                "supported": False,
                "error": f"{self.stat_path} not found. Linux /proc filesystem required.",
            }

        with self._lock:
            # Check if this is the first reading
            if self._prev_overall is None:
                first_overall, first_cores = self._read_stat_lines()
                if first_overall is None:
                    return {
                        "supported": False,
                        "error": f"Failed to parse initial CPU counters from {self.stat_path}",
                    }
                # Setup baseline
                idle_all = (first_overall[3] if len(first_overall) > 3 else 0) + (first_overall[4] if len(first_overall) > 4 else 0)
                non_idle = sum(first_overall[:3]) + sum(first_overall[5:8])
                self._prev_overall = (idle_all, idle_all + non_idle)
                
                for cid, cstats in first_cores.items():
                    c_idle = (cstats[3] if len(cstats) > 3 else 0) + (cstats[4] if len(cstats) > 4 else 0)
                    c_total = c_idle + sum(cstats[:3]) + sum(cstats[5:8])
                    self._prev_cores[cid] = (c_idle, c_total)

                # Sleep brief interval for initial calculation
                time.sleep(0.08)

            # Read current counters
            curr_overall, curr_cores = self._read_stat_lines()
            if curr_overall is None:
                return {
                    "supported": False,
                    "error": f"Failed to read CPU metrics from {self.stat_path}",
                }

            overall_usage, new_overall_tuple = self._compute_usage_from_jiffies(self._prev_overall, curr_overall)
            self._prev_overall = new_overall_tuple

            per_core_usage: Dict[str, float] = {}
            for cid, cstats in sorted(curr_cores.items()):
                prev_c = self._prev_cores.get(cid, self._prev_overall)
                c_usage, new_c_tuple = self._compute_usage_from_jiffies(prev_c, cstats)
                self._prev_cores[cid] = new_c_tuple
                per_core_usage[f"core_{cid}"] = c_usage

            raw_time_stats = {
                "user": curr_overall[0] if len(curr_overall) > 0 else 0,
                "nice": curr_overall[1] if len(curr_overall) > 1 else 0,
                "system": curr_overall[2] if len(curr_overall) > 2 else 0,
                "idle": curr_overall[3] if len(curr_overall) > 3 else 0,
                "iowait": curr_overall[4] if len(curr_overall) > 4 else 0,
                "irq": curr_overall[5] if len(curr_overall) > 5 else 0,
                "softirq": curr_overall[6] if len(curr_overall) > 6 else 0,
                "steal": curr_overall[7] if len(curr_overall) > 7 else 0,
            }

            self._last_sample_time = time.time()

            return {
                "supported": True,
                "cpu_utilization_percent": overall_usage,
                "per_core_utilization": per_core_usage,
                "raw_time_statistics": raw_time_stats,
                "sample_timestamp": self._last_sample_time,
            }

    def get_full_cpu_report(self) -> Dict[str, Any]:
        """Combines static CPU hardware info with dynamic usage measurements."""
        hardware_info = self.parse_cpuinfo()
        utilization_info = self.get_cpu_utilization()

        if not utilization_info.get("supported", False):
            return {
                "supported": False,
                "error": utilization_info.get("error", "Unable to retrieve CPU statistics."),
                "hardware": hardware_info,
            }

        return {
            "supported": True,
            "hardware": hardware_info,
            "utilization": utilization_info,
        }


# Global singleton instance for state preservation between consecutive API calls
_global_cpu_monitor = CPUMonitor()


def get_cpu_info() -> Dict[str, Any]:
    """Helper function to fetch the complete CPU report."""
    return _global_cpu_monitor.get_full_cpu_report()
